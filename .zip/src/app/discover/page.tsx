import React from "react";

const page = () => {
  return <div>Discover</div>;
};

export default page;
