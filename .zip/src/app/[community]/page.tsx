import React from "react";

const page = () => {
  return <div>forum</div>;
};

export default page;
