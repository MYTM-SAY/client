import React from "react";

const page = () => {
  return <div>classroom</div>;
};

export default page;
