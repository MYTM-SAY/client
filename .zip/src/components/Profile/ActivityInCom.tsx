"use client";

import React, { MouseEvent, useState } from "react";
import Posts from "../Posts";
import { Pagination } from "../Pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const ActivityInCom = () => {
  const [active, setActive] = useState(1);
  const posts = Array.from({ length: 40 }, (_, i) => (
    <Posts key={i} isLast={i === 39} />
  ));
  const postPerPage = 8;

  const paginate = (pageNumber: number, e: MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setActive(pageNumber);
  };

  const startIndex = (active - 1) * postPerPage;
  const endIndex = startIndex + postPerPage;
  const currentPosts = posts.slice(startIndex, endIndex);

  return (
    <div className="flex flex-col gap-8 w-full">
      <div className="self-end">
        <Select>
          <SelectTrigger className="w-[380px] bg-white dark:bg-[#282828] text-gray-900 dark:text-white border border-gray-300 dark:border-gray-600">
            <SelectValue placeholder="Activity in Group" />
          </SelectTrigger>
          <SelectContent className="bg-white dark:bg-[#282828] text-gray-900 dark:text-white">
            {[
              { value: "AI Geeks", label: "12 contributions for: AI Geeks" },
              { value: "CSS Geeks", label: "48 contributions for: CSS Geeks" },
              { value: "JS Geeks", label: "52 contributions for: JS Geeks" },
              { value: "BI Geeks", label: "34 contributions for: BI Geeks" },
              { value: "CI Geeks", label: "5 contributions for: CI Geeks" },
            ].map(({ value, label }) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex flex-col gap-16">
        {currentPosts}
        <Pagination
          active={active}
          postsPerPage={postPerPage}
          totalPosts={posts.length}
          paginate={paginate}
        />
      </div>
    </div>
  );
};

export default ActivityInCom;
