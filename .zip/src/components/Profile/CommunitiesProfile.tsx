import React from "react";
import Image from "next/image";
import Btn from "../ui/Btn";
const CommunitiesProfile = () => {
  return (
    <div className="space-y-4">
      <p className="h4 ">Communities</p>
      <div className="p-6 space-y-8 bg-white dark:bg-[#282828] rounded-lg shadow-md">
        {[1, 2, 3].map((_, index) => (
          <div
            key={index}
            className="flex w-full justify-between items-center xsm:flex-col xsm:items-stretch"
          >
            <div>
              <div className="flex gap-4 flex-wrap xsm:justify-center">
                <Image
                  src="/download (3).jpeg"
                  className="rounded-lg"
                  alt="Community"
                  width={56}
                  height={56}
                />
                <div className="dark:text-white">
                  <p>Complete Front-end course</p>
                  <p className="text-gray-600 dark:text-gray-400">
                    Private • 167.6k • Admin
                  </p>
                </div>
              </div>
              <p className="mt-4 text-gray-700 dark:text-gray-300">
                Lorem, ipsum dolor sit amet consectetur
              </p>
            </div>
            <Btn className="px-8 py-4 bg-black text-white dark:bg-white dark:text-black">
              Visit
            </Btn>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommunitiesProfile;
