import React from "react";
import Image from "next/image";
import { Button } from "./ui/button";
import { BiUpvote, BiDownvote } from "react-icons/bi";
import { FaRegComment } from "react-icons/fa";
import { RiShareForwardLine } from "react-icons/ri";
import { LuSettings2 } from "react-icons/lu";
import { PostsProps } from "@/types";

const Posts = ({ isLast }: PostsProps) => {
  return (
    <div className="relative p-6 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white shadow-md">
      <div className="absolute top-4 right-4 w-6 h-6 rounded-lg flex justify-center items-center border-gray-300 dark:border-gray-500 border cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700 transition">
        <LuSettings2 className="text-gray-700 dark:text-gray-300" />
      </div>
      <div className="flex gap-4 items-center">
        <Image
          src="/download (3).jpeg"
          className="rounded-full"
          alt="Profile Image"
          width={40}
          height={40}
        />
        <div>
          <p className="font-semibold">
            {isLast ? "Yousef Tarek" : "Yousef Hassan"}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            6h ago in <strong>General</strong>
          </p>
        </div>
      </div>
      <h2 className="text-xl font-semibold mt-3">
        Curious, how do you manage the full ML lifecycle?
      </h2>
      <p className="mt-2 text-gray-700 dark:text-gray-300">
        Hi guys! I’ve been pondering a specific question/idea that I would like
        to pose as a discussion. It concerns the idea of more quickly going from
        idea...
      </p>
      <div className="flex gap-4 items-center mt-6">
        <Button className="flex items-center gap-2 px-4 py-2 text-gray-900 dark:text-white bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600">
          <BiUpvote className="text-green-500" /> 1.8k{" "}
          <BiDownvote className="text-red-500" />
        </Button>
        <Button className="flex items-center gap-2 px-4 py-2 text-gray-900 dark:text-white bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600">
          <FaRegComment /> 12
        </Button>
        <Button className="flex items-center gap-2 px-4 py-2 text-gray-900 dark:text-white bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600">
          <RiShareForwardLine />
          Share
        </Button>
        <p className="text-blue-600 dark:text-blue-400 ml-4 text-sm">
          New comment 3m ago
        </p>
      </div>
    </div>
  );
};

export default Posts;
